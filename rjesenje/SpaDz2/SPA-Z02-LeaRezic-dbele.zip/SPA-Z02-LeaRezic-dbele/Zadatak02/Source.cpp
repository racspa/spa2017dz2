#include "igraJedenjaVoca.h"

int main()
{
	igraJedenjaVoca igra;
	while (igra.iduciKorak()) {
		igra.iscrtaj();
	}
	return 0;
}