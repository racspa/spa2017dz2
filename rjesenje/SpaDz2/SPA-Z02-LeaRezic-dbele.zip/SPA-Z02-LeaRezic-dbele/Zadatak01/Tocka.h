#ifndef TOCKA_H_
#define TOCKA_H_

#include <iostream>
using namespace std;

struct Tocka
{
	int x;
	int y;
};

#endif // !TOCKA_H_
