#include <iostream>
#include "windows.h"


using namespace std;

struct Tocka
{
	int redak;
	int stupac;
};

void postaviPolje(char polje[][40], Tocka &A, Tocka &B) {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 40; j++) {
			if (i == A.redak - 1 && j == A.stupac - 1) {
				polje[i][j] = 'A';
			}
			else if (i == B.redak - 1 && j == B.stupac - 1) {
				polje[i][j] = 'B';
			}
			else { polje[i][j] = '-'; }
		}
	}
}

void iscrtaj(char polje[][40]) {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 40; j++) {
			cout << polje[i][j];
		}
		cout << endl;
	}
}

void refreshPolje(char polje[][40], Tocka &A, Tocka &B, Tocka &X) {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 40; j++) {
			if (i == A.redak - 1 && j == A.stupac - 1) {
				polje[i][j] = 'A';
			}
			else if (i == B.redak - 1 && j == B.stupac - 1) {
				polje[i][j] = 'B';
			}
			else if (i == X.redak - 1 && j == X.stupac - 1) {
				polje[i][j] = 'x';
			}
			else { polje[i][j] = '-'; }
		}
	}
}

int main() {

	Tocka A;
	Tocka B;

	do {
		cout << "A redak: ";
		cin >> A.redak;
		cout << "A stupac: ";
		cin >> A.stupac;
	} while (!(A.redak > 0 && A.redak < 21 && A.stupac > 0 && A.stupac < 41));

	do {
		cout << "B redak: ";
		cin >> B.redak;
		cout << "B stupac: ";
		cin >> B.stupac;
	} while (!(B.redak > 0 && B.redak < 21 && B.stupac > 0 && B.stupac < 41));

	char polje[20][40];

	postaviPolje(polje,A,B);

	system("cls");

	Tocka X;
	X.redak = A.redak;
	X.stupac = A.stupac;

	iscrtaj(polje);
	system("cls");

	while (X.redak != B.redak && X.stupac != B.stupac)
	{
		do {
			if (B.stupac < A.stupac) {
				X.stupac--;
			}
			else { X.stupac++; }
			refreshPolje(polje, A, B, X);
			iscrtaj(polje);
			Sleep(100);
			system("cls");
		} while (X.stupac != B.stupac);
		
		do {
			if (B.redak < A.redak) {
				X.redak--;
			}
			else { X.redak++; }
			refreshPolje(polje, A, B, X);
			iscrtaj(polje);
			Sleep(100);
			system("cls");
		} while (X.redak != B.redak);
	}
	return 0;
}