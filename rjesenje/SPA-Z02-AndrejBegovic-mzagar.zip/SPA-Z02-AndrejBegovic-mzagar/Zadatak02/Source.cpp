#include <iostream>
#include "windows.h"
#include "conio.h"
#include <ctime>

using namespace std;

struct Pozicija
{
	int x;
	int y;
};

void iscrtajPlocu(char polje[][30]) {
	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 30; j++) {
			cout << polje[i][j];
		}
		cout << endl;
	}
}

void randomVocka(Pozicija &vocka, Pozicija &igrac) {
	while (true)
	{
		vocka.x = rand() % 23 + 1;
		vocka.y = rand() % 28 + 1;
		if (vocka.x != igrac.x && vocka.y != igrac.y) {
			break;
		}
	}
}

void initPolje(char polje[][30], Pozicija &igrac, Pozicija &vocka) {
	for (int i = 0; i < 25; i++) {
		for (int j = 0; j < 30; j++) {
			if (i == 0 || i == 24 || j == 0 || j == 29) {
				polje[i][j] = '#';
			}
			else if (i == igrac.x && j == igrac.y) {
				polje[i][j] = 'X';
			}
			else if (i == vocka.x && j == vocka.y) {
				polje[i][j] = 'D';
			}
			else { polje[i][j] = ' '; }
		}
	}
}

void postaviPolje(char polje[][30], Pozicija &igrac, Pozicija &vocka) {
	for (int i = 1; i < 24; i++) {
		for (int j = 1; j < 29; j++) {
			if (i == igrac.x && j == igrac.y) {
				polje[i][j] = 'X';
			}
			else if (i == vocka.x && j == vocka.y) {
				polje[i][j] = 'D';
			}
			else { polje[i][j] = ' '; }
		}
	}
}

char get_user_input() {
	if (_kbhit()) {
		return _getch();
	}
	return '0';
}

void sljedecaPozicija(Pozicija &igrac, char &key) {
	switch (key) {
	case '0':
		igrac.y++;
		break;
	case 'w':
		igrac.x--;
		break;
	case 's':
		igrac.x++;
		break;
	case 'a':
		igrac.y--;
		break;
	case 'd':
		igrac.y++;
		break;
	}
}


int main() {

	srand(time(nullptr));

	Pozicija igrac;
	igrac.x = 12;
	igrac.y = 15;
	Pozicija vocka;
	randomVocka(vocka, igrac);

	char polje[25][30];
	initPolje(polje, igrac, vocka);

	iscrtajPlocu(polje);

	char key = '0';
	char key_temp;

	while (true)
	{

		Sleep(100);
			
		if (_kbhit()) {
			key_temp = get_user_input();
			key = key_temp;
		}

		if (igrac.x == 0 || igrac.x == 24 || igrac.y == 0 || igrac.y == 29 || key == 'k') {
			break;
		}

		if (igrac.x == vocka.x && igrac.y == vocka.y) {
			randomVocka(vocka, igrac);
		}
		
		system("cls");
		sljedecaPozicija(igrac, key);
		postaviPolje(polje, igrac, vocka);
		iscrtajPlocu(polje);
		
	}
	return 0;
}