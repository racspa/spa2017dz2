#ifndef _POZICIJA_H_
#define _POZICIJA_H_
struct pozicija
{
	int x;	//redak
	int y;	//stupac
};




#endif