#include <iostream>
#include "igra.h"
using namespace std;
int main() {
	igra b;
	do
	{
		system("cls");
		b.ispis();
		b.kretnja_x();
		Sleep(100);
	} while (b.kretnja_x());

	do
	{
		system("cls");
		b.ispis();
		b.kretnja_y();
		Sleep(100);
	} while (b.kretnja_y());
	

	return 0;
}