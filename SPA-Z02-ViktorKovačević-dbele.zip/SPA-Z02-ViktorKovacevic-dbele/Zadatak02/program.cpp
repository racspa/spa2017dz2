#include <iostream>
#include "igra.h"
using namespace std;
int main() {
	char temp;
	igra b;
	b.odabir = 'd';
	
	do
	{
		
	
			system("cls");
			b.ispis();
			b.kretnja(b.odabir);
			Sleep(100);
			temp = b.get_user_input();
			if (temp == 'd' || temp == 'w' || temp == 'a' || temp == 's') {
				b.odabir = temp;
	}
			b.povratak_iz_mrtvih();
			
			
	} while (temp!='k' && b.provjera_granica());
	
	return 0;
}