#ifndef _TOCKA_H_
#define _TOCKA_H_

struct tocka
{
	int x;
	int y;
};



#endif // !_TOCKA_H_
